# بناء TalaNetManager.apk من الهاتف فقط

1. فك ضغط هذا المشروع أو ارفع ZIP كما هو إلى GitHub.
2. أنشئ Repository جديد باسم TalaNetManager.
3. ارفع محتويات المشروع إلى المستودع.
4. افتح تبويب Actions.
5. اختر Build TalaNetManager APK.
6. اضغط Run workflow.
7. انتظر حتى تصبح العملية باللون الأخضر.
8. افتح العملية الناجحة وانزل إلى Artifacts.
9. حمّل TalaNetManager-APK.
10. فك الضغط إذا نزل كـ ZIP وستجد TalaNetManager.apk.
11. اضغط APK من الهاتف واختر تثبيت.

ملاحظة:
ملف build.yml موجود مسبقًا داخل .github/workflows، لذلك لا تحتاج إنشاء Workflow يدويًا.
