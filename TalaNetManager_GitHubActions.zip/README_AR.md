# TalaNetManager Android
مشروع Android Studio جاهز للبناء من نفس نسخة Tala Net Manager الحالية.
- اسم التطبيق: Tala Net Manager
- الحزمة: com.talanet.manager
- الإصدار: 1.0
- الواجهة العربية RTL
- المبيعات والديون والدفعات والتقارير والنسخ الاحتياطي المحلي
- التطبيق يعمل داخل WebView ويستخدم LocalStorage لحفظ البيانات على الجهاز.

## إخراج APK
افتح المجلد في Android Studio ثم:
Build > Build App Bundle(s) / APK(s) > Build APK(s)
الملف الناتج يكون عادة داخل:
app/build/outputs/apk/debug/app-debug.apk
ثم يمكن إعادة تسميته إلى TalaNetManager.apk.

## ملاحظة
هذا مشروع مصدر وليس APK مبنيًا، لأن بناء APK يحتاج Android SDK/Gradle في بيئة البناء.
